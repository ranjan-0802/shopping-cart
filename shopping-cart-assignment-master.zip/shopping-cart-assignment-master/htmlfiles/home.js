const swiper = new Swiper(".swiper", {
  // Optional parameters
  direction: "horizontal",
  loop: true,

  // If we need pagination
  pagination: {
    el: ".swiper-pagination",
  },

  // Navigation arrows
  navigation: {
    nextEl: ".swiper-button-next",
    prevEl: ".swiper-button-prev",
  },
});

const bannerCards = document.querySelector("#banner-cards");
// banner cards js
async function getBannerData() {
  try {
    let result = await fetch("../server/categories/index.get.json");
    let banners = await result.json();
    banners.sort((i1, i2) => i1.order - i2.order);
    window.banners = banners;
    bannerCards.innerHTML = banners
      .map(
        (item) =>
          `<div class="cards">
        <div class="${item.order % 2 == 0 ? "left" : "right"}-section-card">
          <img
            src="${item.imageUrl}"
            alt=""
            height="300px"
            width="500px"
          />
        </div>
        <div class="${item.order % 2 == 1 ? "left" : "right"}-section-card">
          <h2>${item.name}</h2>
          <p>${item.description}</p>
          <button >Explore ${item.key}</button>
        </div></div>`
      )
      .join(" ");

    return banners;
  } catch (error) {
    console.log(error);
  }
}
getBannerData();

function cartModal() {}
